<html>
<head>
</head>

<body>

<p>{{ $email }}</p>
<p>{{ $password }}</p>




	</body>
</html>


