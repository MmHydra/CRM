<!Doctype html>
<html>
<head>
	<title></title>
</head>
<body>
	<div>here's test</div>
<div>
	<?php echo $__env->yieldContent('content'); ?>
</div>
</body>
</html><?php /**PATH /home/vagrant/first/resources/views/test/testBlade1.blade.php ENDPATH**/ ?>