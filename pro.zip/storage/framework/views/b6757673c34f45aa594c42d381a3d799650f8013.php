<html>
<head><meta charset="utf-8"></head>
<body>
<!-- <form>
	<form method="GET" autocomplete="off">
		<input placeholder="click"></input>
	 <button onclick="redirect();">Войти</button>

</form> -->

<h1>HEADER</h1>

 <hr>

</body>

</html><?php /**PATH /home/vagrant/first/resources/views/show.blade.php ENDPATH**/ ?>