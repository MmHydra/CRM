<html>
<head>
</head>

<body>

<p><?php echo e($email); ?></p>
<p><?php echo e($password); ?></p>




	</body>
</html>


<?php /**PATH /home/vagrant/first/resources/views/index-selectfromDB.blade.php ENDPATH**/ ?>