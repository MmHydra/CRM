<html>
    <head>
        <title></title>
    </head>
    <body>
    
        <h1>Works</h1>

     
       
        
    </body>
</html><?php /**PATH /home/vagrant/first/resources/views/DataPanel.blade.php ENDPATH**/ ?>