<html>
    <head>
        <title></title>
    </head>
    <body>
    
        <h1><?php echo $__env->yieldContent('h1'); ?></h1>

     
       
        
    </body>
</html>

<?php /**PATH /home/vagrant/first/resources/views/BladeTestFirst.blade.php ENDPATH**/ ?>