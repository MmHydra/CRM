<html>
    <head>
        <title></title>
    </head>
    <body>
    
        <h1>@yield('h1')</h1>

     
       
        
    </body>
</html>

