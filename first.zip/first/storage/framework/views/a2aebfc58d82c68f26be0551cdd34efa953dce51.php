

<?php $__env->startSection('body'); ?>


<?php $__currentLoopData = $Data_Accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <p>Это строка <?php echo e($Data); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('API.Capsule', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/first/resources/views/API/testViewResponce.blade.php ENDPATH**/ ?>