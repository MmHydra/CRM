



<?php echo $__env->make('API.Capsule', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/first/resources/views/API/test-index.blade.php ENDPATH**/ ?>