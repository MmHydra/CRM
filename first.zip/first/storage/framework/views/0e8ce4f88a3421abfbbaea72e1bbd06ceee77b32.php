<?php $__env->startSection('h1'); ?>
slgnpignsepigngoiengoeinginge
<?php $__env->stopSection(); ?>


<?php echo $__env->make('BladeTestFirst', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/first/resources/views/BladeTestSecond.blade.php ENDPATH**/ ?>